#include "testlib.h"

#include <algorithm>
#include <assert.h>
#include <iostream>
#include <numeric>
#include <unordered_set>

const double DEFAULT_WEIGHT = 1.0;

double compute_test_weight() {
    return DEFAULT_WEIGHT;
}

int get_trace_size() {
    inf.readInts(7);
    int n_flv = inf.readInt();
    inf.readInts(3 * n_flv);
    int size = 0;
    while(1) {
        int tp = inf.readInt();
        if (tp == 1) {
            inf.readInts(3);
        } else if (tp == 2) {
            int s = inf.readInt();
            inf.readInts(2 + s);
            size += s;
        } else if (tp == 3) {
            int s = inf.readInt();
            inf.readInts(s);
        } else {
            break;
        }
    }
    return size;
}

int main(int argc, char ** argv) {
    registerTestlibCmd(argc, argv);

    int placed = ouf.readInt();

    int placed_jury = ans.readInt();

    double score = placed / (double)std::max(1, placed_jury);
    double w = compute_test_weight();
    
    int sz = get_trace_size();
    std::cerr << std::fixed << placed * 100.0 / sz << "% trace placed" << std::endl;

    std::cout.precision(2);
    std::cout << std::fixed << int(100000 * score * w) << std::endl;
    quit(_ok, "ok");
}
