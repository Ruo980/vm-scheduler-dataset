# usage: python3 runall.py %input_directory% %ub_directory% -- %command to run the solution%
# example: python3 runall.py data/ ub/ -- python3 solution.py
# this script runs the solution on all tests and outputs the results into results.json


import json
import subprocess
import sys
import uuid

from pathlib import Path


def parse_result(test, stdout):
    tokens = stdout.split()
    if tokens[0] != "ok":
        return {"id": test.stem, "status": tokens[0]}
    else:
        return {"id": test.stem, "status": tokens[0], "points": int(tokens[1])}


def main(data_path, baseline_results_path, cmd):
    results = []
    pts = 0
    for test in data_path.glob('*.txt'):
        tmp_name = Path(uuid.uuid4().hex + '.txt')
        curr_cmd = ['./runexe', test, tmp_name, baseline_results_path/test.name, '--'] + cmd
        ret = subprocess.run(curr_cmd, capture_output=True)
        try:
            tmp_name.unlink()
        except FileNotFoundError:
            pass
        if ret.returncode != 0:
            raise RuntimeError("runexe crashed")
        result = parse_result(test, ret.stdout.decode('utf-8'))
        if "points" in result:
            pts += result["points"]
        results.append(result)
    with open('results.json', 'w') as f:
        message = "all tests are ok"
        for result in results:
            if result["status"] != "ok":
                if result["status"] == "wa":
                    verdict = "program printed invalid answer"
                elif result["status"] == "re":
                    verdict = "program crashed with non-zero exit code"
                elif result["status"] == "tl":
                    verdict = "time limit exceeded"
                elif result["status"] == "ml":
                    verdict = "memory limit exceeded"
                else:
                    verdict = result["status"]
                message = f"Some tests failed. First failed test: {result['id']}, verdict: {verdict}"
                break
        f.write(json.dumps({"results": results, "total_score": pts, "total_test_cases": len(results), "message": message}, indent=4))


if __name__ == '__main__':
    assert len(sys.argv) >= 5
    assert sys.argv[3] == '--'
    main(Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[4:])
