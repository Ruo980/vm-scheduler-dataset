#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/resource.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

const int TIME_LIMIT = 30;
const int MEM_LIMIT = 512 * 1024 * 1024;

// run this code as ./runexe %input_file% %output_file% %baseline_results% -- %command to run the solution%
// to test solution_executable on input_file
// it assumes that interactor is named 'interactor'
// example: ./runexe data/000.txt 000.a -- java -jar solution.jar
int
main(int argc, char ** argv)
{
    int int_to_sol[2];
    int sol_to_int[2];
    if(-1 == pipe(int_to_sol)) {
        fprintf(stderr, "Can't open pipe!\n");
        exit(1);
    }
    if(-1 == pipe(sol_to_int)) {
        fprintf(stderr, "Can't open pipe!\n");
        exit(1);
    }
    pid_t pid1 = fork();
    if(pid1 == -1) {
        fprintf(stderr, "Can't fork!\n");
        exit(1);
    }
    if(pid1 == 0) {
        dup2(sol_to_int[0], 0);
        dup2(int_to_sol[1], 1);
        //execl("interactor", "interactor", argv[1], argv[2], (char*)NULL);
        char* interactor_tl = malloc(4);
        sprintf(interactor_tl, "%d", TIME_LIMIT + 3);
        execlp("timeout", "timeout", interactor_tl, "./interactor", argv[1], argv[2], (char*)NULL);
    } else {
        pid_t pid2 = fork();
        if(pid2 == -1) {
            kill(pid1, SIGKILL);
            fprintf(stderr, "Can't fork!\n");
            exit(1);
        }
        if(pid2 == 0) {
            dup2(int_to_sol[0], 0);
            dup2(sol_to_int[1], 1);
            int cmd_len = argc - 5;
            char ** cmd = malloc((cmd_len + 3) * sizeof(char*));
            cmd[0] = "timeout";
            //cmd[1] = "--preserve-status";
            cmd[1] = malloc(4);
            sprintf(cmd[1], "%d", TIME_LIMIT);
            for (int i = 2; i < cmd_len + 2; i++) {
                cmd[i] = argv[5 + i - 2];
            }
            cmd[cmd_len + 2] = NULL;
            if (strcmp(cmd[2], "java") != 0 && strcmp(cmd[2], "/usr/bin/java") != 0) {
                struct rlimit mem_limit;
                mem_limit.rlim_cur = mem_limit.rlim_max = MEM_LIMIT;
                setrlimit(RLIMIT_AS, &mem_limit);
            }
            execvp(cmd[0], cmd);
        } else {
            int status1 = 0;
            int who = waitpid(-1, &status1, 0);
            if (who == pid2) {
                if (!WIFEXITED(status1) || WEXITSTATUS(status1) != 0) {
                    kill(pid1, SIGKILL);
                    if (WEXITSTATUS(status1) == 124) {//(WIFSIGNALED(status1) && WTERMSIG(status1) == SIGTERM) {
                        // probably tl violated
                        printf("tl\n");
                        return 0;
                    }
                    if (WIFSIGNALED(status1) && WTERMSIG(status1) == SIGKILL) {
                        // probably ml violated
                        printf("ml\n");
                        return 0;
                    }
                    printf("re\n");
                    return 0;
                } else {
                    int int_status = 0;
                    waitpid(pid1, &int_status, 0);
                    int_status = WEXITSTATUS(int_status);
                    if (int_status == 124) {//WIFSIGNALED(int_status) && WTERMSIG(int_status) == SIGTERM) {
                        // probably interaction protocol violated, and the interactor hung
                        // we will count it as tl
                        printf("tl\n");
                        return 0;
                    }
                    if (int_status > 0) {
                        printf("wa\n");
                        return 0;
                    }
                    printf("ok\n");
                    fflush(stdout);
                    execl("checker", "checker", argv[1], argv[2], argv[3], (char*)NULL);
                }
            } else {
                assert(who == pid1);
                kill(pid2, SIGKILL);
                if (WEXITSTATUS(status1) != 0) {
                    if (WEXITSTATUS(status1) == 124) {
                    //if (WIFSIGNALED(status1) && WTERMSIG(status1) == SIGTERM) {
                        printf("tl\n");
                        return 0;
                    }
                    printf("wa\n");
                    return 0;
                }
                printf("ok\n");
                fflush(stdout);
                execl("checker", "checker", argv[1], argv[2], argv[3], (char*)NULL);
            }
        }
    }
    return 0;
}
