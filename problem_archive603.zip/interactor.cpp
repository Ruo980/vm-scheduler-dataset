#include "testlib.h"

#include <iostream>
#include <fstream>
#include <set>
#include <unordered_set>
#include <unordered_map>
#include <vector>

#define safe_quitf(...) std::cout<<4<<std::endl;quitf(__VA_ARGS__)

struct VMType {
    int cpu;
    int mem;
    int numas;
};

struct Placement {
    int net_domain = -1;
    int pod = -1;
    int pod_id = -1; // cluster-wide pod id
    int rack = -1;
    int rack_id = -1; // cluster-wide rack id
    int pm = -1;
    int pm_id = -1; // cluster-wide PM id
    int numa1 = -1;
    int numa2 = -1;
    int partition = -1; // for rack anti-affinity only

    Placement() {}
    Placement(int net_domain_, int pod_, int pod_id_, int rack_, int rack_id_, int pm_, int pm_id_, int numa1_, int numa2_, int partition_):
        net_domain(net_domain_), pod(pod_), pod_id(pod_id_), rack(rack_), rack_id(rack_id_), pm(pm_), pm_id(pm_id_), numa1(numa1_), numa2(numa2_), partition(partition_) {}
};

enum class Affinity {
    NO,
    RACK,
    POD,
    DOMAIN
};

enum class AntiAffinity {
    NO,
    SERVER,
    RACK
};

struct PG {
    Affinity affinity;
    AntiAffinity antiaffinity;
    bool whole_pod;
    int partitions;

    std::unordered_map<int, int> rack_partition;
    std::unordered_map<int, int> rack_vm_count;
    std::unordered_map<int, int> pod_vm_count;
    std::unordered_map<int, int> net_vm_count;
    std::unordered_map<int, int> host_vm_count;
    std::unordered_map<int, int> partition_vm_count;
    std::multiset<int> ordered_partitions;
    int alive_vms = 0;

    PG(Affinity a, AntiAffinity aa, bool wp, int p): affinity(a), antiaffinity(aa), whole_pod(wp), partitions(p) {
        for (int i = 0; i < partitions; i++) {
            ordered_partitions.insert(0);
        }
    }

    void new_placement(const Placement & placement, bool ignore_disbalance) {
        ++alive_vms;
        if (antiaffinity == AntiAffinity::SERVER) {
            host_vm_count[placement.pm_id] += 1;
            if (host_vm_count[placement.pm_id] > 1) {
                safe_quitf(_wa, "Server antiaffinity violated.");
            }
        }
        if (antiaffinity == AntiAffinity::RACK || affinity == Affinity::RACK || partitions > 1) {
            rack_vm_count[placement.rack_id] += 1;
            if (antiaffinity == AntiAffinity::RACK && rack_vm_count[placement.rack_id] > 1) {
                safe_quitf(_wa, "Rack antiaffinity violated.");
            }
            if (affinity == Affinity::RACK && rack_vm_count[placement.rack_id] != alive_vms) {
                safe_quitf(_wa, "Rack affinity violated.");
            }
            if (partitions > 1) {
                if (rack_vm_count[placement.rack_id] > 1) {
                    int old = rack_partition[placement.rack_id];
                    if (old != placement.partition) {
                        safe_quitf(_wa,
                                "Antiaffinity with partitions violated: placing partition %d on rack occupied by partition %d.",
                                placement.partition, old);
                    }
                } else {
                    rack_partition[placement.rack_id] = placement.partition;
                }
                ordered_partitions.erase(ordered_partitions.find(partition_vm_count[placement.partition]));
                partition_vm_count[placement.partition] += 1;
                ordered_partitions.insert(partition_vm_count[placement.partition]);
                if (!ignore_disbalance && *(--ordered_partitions.end()) - *ordered_partitions.begin() > 1) {
                    safe_quitf(_wa, "Antiaffinity with partitions violated: VMs are not spread evenly, some partitions have 2 or more difference.");
                }
            }
        }
        if (affinity == Affinity::POD) {
            pod_vm_count[placement.pod_id] += 1;
            if (pod_vm_count[placement.pod_id] != alive_vms) {
                safe_quitf(_wa, "Pod affinity violated.");
            }
        }
        if (affinity == Affinity::DOMAIN) {
            net_vm_count[placement.net_domain] += 1;
            if (net_vm_count[placement.net_domain] != alive_vms) {
                safe_quitf(_wa, "Network domain affinity violated.");
            }
        }
    }

    void delete_placement(const Placement & placement) {
        --alive_vms;
        if (antiaffinity == AntiAffinity::SERVER) {
            host_vm_count[placement.pm_id] -= 1;
        }
        if (antiaffinity == AntiAffinity::RACK || affinity == Affinity::RACK || partitions > 1) {
            rack_vm_count[placement.rack_id] -= 1;
            if (partitions > 1) {
                ordered_partitions.erase(ordered_partitions.find(partition_vm_count[placement.partition]));
                partition_vm_count[placement.partition] -= 1;
                ordered_partitions.insert(partition_vm_count[placement.partition]);
            }
        }
        if (affinity == Affinity::POD) {
            pod_vm_count[placement.pod_id] -= 1;
        }
        if (affinity == Affinity::DOMAIN) {
            net_vm_count[placement.net_domain] -= 1;
        }
    }
};

PG get_pg_by_type(int tp, int partitions) {
    if (tp != 6 && partitions > 1) {
        safe_quitf(_fail, ">1 partitions for group with type != 6");
    }
    switch (tp) {
        case 0:
            return PG(Affinity::NO, AntiAffinity::NO, false, partitions);
        case 1:
            return PG(Affinity::RACK, AntiAffinity::NO, false, partitions);
        case 2:
            return PG(Affinity::POD, AntiAffinity::NO, false, partitions);
        case 3:
            return PG(Affinity::DOMAIN, AntiAffinity::NO, false, partitions);
        case 4:
            return PG(Affinity::NO, AntiAffinity::SERVER, false, partitions);
        case 5:
            return PG(Affinity::NO, AntiAffinity::RACK, false, partitions);
        case 6:
            return PG(Affinity::NO, AntiAffinity::NO, false, partitions);
        case 7:
            return PG(Affinity::RACK, AntiAffinity::SERVER, false, partitions);
        case 8:
            return PG(Affinity::DOMAIN, AntiAffinity::RACK, false, partitions);
        case 9:
            return PG(Affinity::DOMAIN, AntiAffinity::NO, true, partitions);
        default:
            safe_quitf(_fail, "Unknown group type: %d", tp);
    }
}

struct VM {
    int type_id;
    int pg_id;
    Placement placement;

    VM(int type_id, int pg_id, Placement placement):
        type_id(type_id), pg_id(pg_id), placement(placement) {}
};

struct NUMA {
    int cpu_used;
    int mem_used;
    int cpu_total;
    int mem_total;

    NUMA(int cpu_total, int mem_total):
        cpu_used(0), mem_used(0), cpu_total(cpu_total), mem_total(mem_total) {}

    void allocate(const VMType & vm) {
        cpu_used += vm.cpu;
        if (cpu_used > cpu_total) {
            safe_quitf(_wa, "NUMA CPU capacity constraint is violated: %d > %d", cpu_used, cpu_total);
        }
        mem_used += vm.mem;
        if (mem_used > mem_total) {
            safe_quitf(_wa, "NUMA memory capacity constraint is violated: %d > %d", mem_used, mem_total);
        }
    }

    void release(const VMType & vm) {
        // resources will never underflow
        cpu_used -= vm.cpu;
        mem_used -= vm.mem;
    }
};

void end_interaction(int placed, double cpu_usage, double memory_usage, bool finished) {
    tout << placed << std::endl;
    if (finished) {
        quitf(_ok,
            "Interaction ended with %d placed VMs, CPU allocation rate = %f, memory allocation rate = %f. Trace is finished.",
            placed, cpu_usage, memory_usage);
    } else {
        quitf(_ok,
            "Interaction ended with %d placed VMs, CPU allocation rate = %f, memory allocation rate = %f. Trace is not finished.",
            placed, cpu_usage, memory_usage);
    }
}

int main(int argc, char ** argv) {
    registerInteraction(argc, argv);

    // number of network domains
    int n_net = inf.readInt();
    // number of pods in each domain
    int n_pod = inf.readInt();
    // number of racks in each pod
    int n_rack = inf.readInt();
    // number of PMs in each rack
    int n_pm = inf.readInt();
    // number of NUMAs in each PM
    int n_numa = inf.readInt();

    int pm_cpu_capacity = 0;
    int pm_memory_capacity = 0;

    std::vector<int> numa_cpu_total(n_numa), numa_mem_total(n_numa);
    numa_cpu_total[0] = inf.readInt();
    numa_mem_total[0] = inf.readInt();
    for (int i = 1; i < n_numa; i++) {
        numa_cpu_total[i] = numa_cpu_total[i - 1];
        numa_mem_total[i] = numa_mem_total[i - 1];
    }
    pm_cpu_capacity = numa_cpu_total[0] * n_numa;
    pm_memory_capacity = numa_mem_total[0] * n_numa;

    int total_pm_count = n_pm * n_rack * n_pod * n_net;
    int total_cpu_capacity = pm_cpu_capacity * total_pm_count;
    int total_memory_capacity = pm_memory_capacity * total_pm_count;
    int cpu_usage = 0;
    int memory_usage = 0;

    std::vector<std::vector<std::vector<std::vector<std::vector<NUMA>>>>> numa(n_net);
    for (int i = 0; i < n_net; i++) {
        numa[i].resize(n_pod);
        for (int j = 0; j < n_pod; j++) {
            numa[i][j].resize(n_rack);
            for (int k = 0; k < n_rack; k++) {
                numa[i][j][k].resize(n_pm);
                for (int t = 0; t < n_pm; t++) {
                    numa[i][j][k][t].reserve(n_numa);
                    for (int l = 0; l < n_numa; l++) {
                        numa[i][j][k][t].emplace_back(numa_cpu_total[l], numa_mem_total[l]);
                    }
                }
            }
        }
    }

    // number of VM types
    int n_types = inf.readInt();
    std::vector<VMType> types(n_types);
    for (int i = 0; i < n_types; i++) {
        types[i].numas = inf.readInt();
        types[i].cpu = inf.readInt();
        types[i].mem = inf.readInt();
    }

    // Pass resource pool configuration to algorithm
    std::cout << n_net << ' ' << n_pod << ' ' << n_rack << ' ' << n_pm << ' ' << n_numa << '\n';
    std::cout << numa_cpu_total[0] << ' ' << numa_mem_total[0] << '\n';
    // Pass VM types to algorithm
    std::cout << n_types << '\n';
    for(int i = 0; i < n_types; i++) {
        std::cout << types[i].numas << ' ' << types[i].cpu << ' ' << types[i].mem << '\n';
    }
    std::cout.flush();

    // Main interaction loop
    std::vector<PG> pgs;
    std::vector<VM> vms;
    int placed = 0;
    int request_id = 0;
    std::vector<std::vector<int>> vm_ids;

    for (;; request_id++) {
        //std::cerr << request_id << " " << vms.size() << " " << pgs.size() << " " << std::endl;
        vm_ids.emplace_back();
        int id = inf.readInt();
        std::cout << id << std::endl;
        // PG creation
        if (id == 1) {
            int j = inf.readInt();
            int tp = inf.readInt();
            int k = inf.readInt();
            std::cout << j << ' ' << tp << ' ' << k << std::endl;
            if (k == 0) {
                k = 1;
            }
            pgs.emplace_back(get_pg_by_type(tp, k));
        // VM creation
        } else if (id == 2) {
            int l = inf.readInt();
            int f = inf.readInt();
            int g = inf.readInt();
            std::cout << l << ' ' << f << ' ' << g << '\n';
            vm_ids[request_id].resize(l);
            VMType vm_type = types[f - 1];
            PG & pg = pgs[g - 1];
            for (int i = 0; i < l; i++) {
                vm_ids[request_id][i] = inf.readInt() - 1;
                if (i > 0) {
                    std::cout << ' ';
                }
                std::cout << vm_ids[request_id][i] + 1;
            }
            std::cout << std::endl;
            std::unordered_set<int> pods;
            bool ok = true;
            // Process algorithm response
            for (int i = 0; i < l; i++) {
                int net_domain = ouf.readInt(-1, n_net);
                if (net_domain == 0) {
                    safe_quitf(_wa, "Network domain id can't be 0.");
                }
                if (net_domain == -1 && i > 0) {
                    safe_quitf(_wa, "Partial placements are forbidden.");
                }
                if (net_domain == -1) {
                    ok = false;
                    break;
                }
                --net_domain;
                int pod = ouf.readInt(1, n_pod) - 1;
                int rack = ouf.readInt(1, n_rack) - 1;
                int pm = ouf.readInt(1, n_pm) - 1;
                int numa1 = ouf.readInt(1, n_numa) - 1;
                numa[net_domain][pod][rack][pm][numa1].allocate(vm_type);
                int numa2 = -1;
                if (vm_type.numas == 2) {
                    numa2 = ouf.readInt(1, n_numa) - 1;
                    if (numa1 == numa2) {
                        safe_quitf(_wa, "2-NUMA VMs should be placed on different NUMAs!");
                    }
                    numa[net_domain][pod][rack][pm][numa2].allocate(vm_type);
                }
                int partition_lower_bound = pg.partitions > 1 ? 1 : 0;
                int partition_upper_bound = pg.partitions > 1 ? pg.partitions : 0;
                int partition = ouf.readInt(partition_lower_bound, partition_upper_bound) - 1;
                int pod_id = net_domain * n_pod + pod;
                pods.insert(pod_id);
                int rack_id = net_domain * n_pod * n_rack + pod * n_rack + rack;
                int pm_id = net_domain * n_pod * n_rack * n_pm + pod * n_rack * n_pm + rack * n_pm + pm;
                Placement placement = Placement(net_domain, pod, pod_id, rack, rack_id, pm, pm_id, numa1, numa2, partition);
                VM vm = VM(f - 1, g - 1, placement);
                vms.push_back(vm);
                pg.new_placement(placement, i + 1 < l);
            }
            if (!ok) {
                end_interaction(placed, double(cpu_usage) / total_cpu_capacity, double(memory_usage) / total_memory_capacity, false);
                break;
            }
            if (pg.whole_pod && pods.size() != l / (n_rack * n_pm) ) {
                safe_quitf(_wa, "Whole pod allocation violated.");
            }
            placed += l;
            cpu_usage += l * vm_type.cpu * vm_type.numas;
            memory_usage += l * vm_type.mem * vm_type.numas;
        // VM deletion
        } else if (id == 3) {
            int l = inf.readInt();
            vm_ids[request_id].resize(l);
            for (int i = 0; i < l; i++) {
                vm_ids[request_id][i] = inf.readInt() - 1;
                VM vm = vms[vm_ids[request_id][i]];
                Placement p = vm.placement;
                VMType vm_type = types[vm.type_id];
                cpu_usage -= vm_type.cpu * vm_type.numas;
                memory_usage -= vm_type.mem * vm_type.numas;
                pgs[vm.pg_id].delete_placement(p);
                numa[p.net_domain][p.pod][p.rack][p.pm][p.numa1].release(vm_type);
                if (p.numa2 != -1)
                    numa[p.net_domain][p.pod][p.rack][p.pm][p.numa2].release(vm_type);
            }
            std::cout << l << ' ';
            for (int i = 0; i < l; i++) {
                if (i > 0) {
                    std::cout << ' ';
                }
                std::cout << vm_ids[request_id][i] + 1;
            }
            std::cout << std::endl;
        } else {
            end_interaction(placed, double(cpu_usage) / total_cpu_capacity, double(memory_usage) / total_memory_capacity, true);
            break;
        }
    }
}
